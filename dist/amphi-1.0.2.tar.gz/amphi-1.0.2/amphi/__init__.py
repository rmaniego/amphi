""" amphi """
from .version import version as __version__
from .amphi import Amphi
__all__ = ["amphi"]