""" amphi """
from .version import version as __version__
from .amphi import amphi
__all__ = ["amphi"]